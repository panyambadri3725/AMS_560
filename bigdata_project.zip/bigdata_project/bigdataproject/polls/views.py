import requests
from django.http import HttpResponse
from django.shortcuts import render
from django.core.paginator import Paginator
import json
# Define the API endpoint
API_URL = "https://search-ams560g25-h2csy4rjamwm6l5364m2rwlyjq.aos.us-east-2.on.aws/products/_search"  # Replace with the actual API URL
USERNAME = "admin"  # Replace with your actual username
PASSWORD = "Admin123."
def fetch_articles():
    """
    Fetch articles from the API and structure their reviews.
    """
    try:
        headers = {
            'Accept': 'application/json'
        }
        params = {
            "size": 1000,  # Fetch up to 1000 records
        }
        response = requests.request(
            method="GET",
            url=API_URL,
            auth=(USERNAME, PASSWORD),
            headers=headers,
            params=params
        )
        response.raise_for_status()
        json_data = response.json()

        # Extract articles from '_source' and structure reviews
        articles = [
            {
                **item['_source'],
                "reviews": [
                    {
                        "stars": review.get("stars", "N/A"),
                        "title": review.get("title", "No Title"),
                        "date": review.get("date", "No Date"),
                        "text": review.get("text", "No Content")
                    }
                    for review in item['_source'].get("reviews", [])
                ]
            }
            for item in json_data.get('hits', {}).get('hits', []) if '_source' in item
        ]
        return articles
    except requests.RequestException as e:
        print(f"Error fetching articles: {e}")
        return []

def index(request):
    """
    Handle the index view with search and pagination.
    Display all records by default. Filter records by category when the user clicks the search button.
    """
    # Fetch articles from the API
    articles = fetch_articles()
    print(len( articles))  # Debugging to check fetched data

    # Get the search query from the request (search is triggered when the button is clicked)
    query = request.GET.get('search', '')  # Convert query to lowercase for case-insensitive search
    print("Search Query:", query)  # Debugging to check search query

    # Filter articles by category if a search query is provided
    if query:
        headers = {
            'Accept': 'application/json',  # Specifies the type of response expected
            'Content-Type': 'application/json'  # Specifies the type of data sent in the request body
        }

        params = {
            "size": 1000,  # Fetch up to 100 records
        }
        payload = json.dumps(
        {
            "query": {
                "term": {
                    "category": {"value": query, "case_insensitive": True}
                }
            }
        }
        )
        response = requests.request(
            method="GET",  # Specify the HTTP method
            url=API_URL,  # Specify the URL
            auth=(USERNAME, PASSWORD),  # Basic Authentication
            headers=headers,  # Headers for the request
            params=params,
            data=payload
        )
        response.raise_for_status()  # Raise an exception for HTTP errors
        json_data = response.json()  # Parse the JSON response

        # Extract articles from '_source'
        articles2 = [item['_source'] for item in json_data.get('hits', {}).get('hits', []) if '_source' in item]
        print("len ",len(articles2))
        filtered_articles = [
            {
                "id": article.get("asin", "N/A"),
                "Ratings":article.get("ratings","N/A"),
                "Reviews":article.get("reviews","N/A"),
                "title": article.get("title", "Untitled"),
                "stars": article.get("stars", "N/A"),
                "ratings": article.get("ratings", "N/A"),
                "category": article.get("category", "Uncategorized")
            }
            for article in articles2
        ]
    else:
        # Display all articles if no query is provided
        filtered_articles = [
            {
                "id":article.get("asin","N/A"),
                "Ratings": article.get("ratings", "N/A"),
                "Reviews": article.get("reviews", "N/A"),
                "title": article.get("title", "Untitled"),
                "stars": article.get("stars", "N/A"),
                "ratings": article.get("ratings", "N/A"),
                "category": article.get("category", "Uncategorized")
            }
            for article in articles
        ]

    print("Filtered Articles:", len(filtered_articles))  # Debugging to check filtered data

    # Pagination: Display 10 articles per page
    paginator = Paginator(filtered_articles, 10)
    page_number = request.GET.get('page', 1)
    page_obj = paginator.get_page(page_number)

    return render(request, 'test.html', {
        'page_obj': page_obj,
        'query': query,
    })

def article_detail(request, article_id):
    """
    Render the detail view of a single article.
    """
    # Fetch articles from the API
    print("id is",article_id)
    articles = fetch_articles()
    article = next((item for item in articles if item["asin"] == article_id), None)

    if not article:
        return render(request, '404.html', {"error": "Article not found"})  # Handle case when article is not found

    return render(request, 'article_detail.html', {
        'article': article
    })